package com.room.admin.dto;

import lombok.Data;

@Data
public class RoomKindDTO {
	private  int room_bno;
	private String room_class;
	private int room_cnt;
}
