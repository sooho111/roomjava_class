package com.room.admin.dto;


import lombok.Data;


@Data
public class Room_rentDTO {

	private int rent_bno;
	private String rent_name;
	private int rent_price;

}
