package com.room.admin.dto;


import lombok.Data;


@Data
public class PaymentDTO {

	private int pay_bno;
	private String pay_name;
	private String pay_account;
	private String pay_bank;
}
