package com.room.admin.dto;


import lombok.Data;


@Data
public class Room_fncDTO {

	private int fnc_bno;
	private String fnc_name;
	private int fnc_price;

}
